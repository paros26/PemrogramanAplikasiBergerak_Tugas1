package com.example.shopping_chart

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
